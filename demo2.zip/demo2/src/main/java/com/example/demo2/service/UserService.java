package com.example.demo2.service;

import com.example.demo2.model.User;

import java.util.List;

public interface UserService {
    List<User> select();
    int deleteById(Integer id);
    int insert(User record);
    User selectById(Integer id);
    int updateById(User record);
}
