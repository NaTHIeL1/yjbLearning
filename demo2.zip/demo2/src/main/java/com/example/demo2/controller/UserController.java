package com.example.demo2.controller;

import com.example.demo2.model.User;
import com.example.demo2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping(value = "/select")
    public @ResponseBody
    Object select(){return userService.select();}

    @GetMapping(value = "/delete")
    public @ResponseBody
    Object delete(){return userService.deleteById(1);}

    User user=new User(3,"jjc",13);
    @GetMapping(value = "/insert")
    public @ResponseBody
    Object insert(){return userService.insert(user);}

    @GetMapping(value = "/selectById")
    public @ResponseBody
    Object selectById(){return userService.selectById(2);}

    User user1=new User(2,"def",13);
    @GetMapping(value = "/updateById")
    public @ResponseBody
    Object updateById(){return userService.updateById(user1);}
}
